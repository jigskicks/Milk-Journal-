# HAP Milk Journal 🥛

A daily milk collection journal with Google Drive sync.

## Features
- Smart SMS paste (auto-detects entries)
- Morning & Evening session logging
- Feed expense tracking
- Monthly profit analysis
- Google Drive sync (data saved to your own Drive)

## Setup
1. Add your Google Client ID in Vercel environment variables:
   - Key: `REACT_APP_GOOGLE_CLIENT_ID`
   - Value: your Client ID from Google Cloud Console

2. Deploy via Vercel (auto-deploys from this repo)
