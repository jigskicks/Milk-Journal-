const FOLDER_NAME = 'HAP Milk Journal';
const ENTRIES_FILE = 'entries.json';
const EXPENSES_FILE = 'expenses.json';

async function apiFetch(url, options = {}, token) {
  const res = await fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });
  if (!res.ok) throw new Error(`Drive API error: ${res.status}`);
  return res.json();
}

export async function getOrCreateFolder(token) {
  // Search for existing folder
  const search = await apiFetch(
    `https://www.googleapis.com/drive/v3/files?q=name='${FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false&fields=files(id,name)`,
    {}, token
  );
  if (search.files && search.files.length > 0) return search.files[0].id;

  // Create folder
  const created = await apiFetch(
    'https://www.googleapis.com/drive/v3/files',
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: FOLDER_NAME, mimeType: 'application/vnd.google-apps.folder' }),
    }, token
  );
  return created.id;
}

async function getFileId(token, folderId, fileName) {
  const search = await apiFetch(
    `https://www.googleapis.com/drive/v3/files?q=name='${fileName}' and '${folderId}' in parents and trashed=false&fields=files(id,name)`,
    {}, token
  );
  if (search.files && search.files.length > 0) return search.files[0].id;
  return null;
}

async function readFile(token, fileId) {
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) return null;
  return res.json();
}

async function writeFile(token, folderId, fileName, data, existingId = null) {
  const content = JSON.stringify(data);
  const blob = new Blob([content], { type: 'application/json' });

  if (existingId) {
    // Update existing
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify({ name: fileName })], { type: 'application/json' }));
    form.append('file', blob);
    await fetch(
      `https://www.googleapis.com/upload/drive/v3/files/${existingId}?uploadType=multipart`,
      { method: 'PATCH', headers: { Authorization: `Bearer ${token}` }, body: form }
    );
  } else {
    // Create new
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify({ name: fileName, parents: [folderId] })], { type: 'application/json' }));
    form.append('file', blob);
    await fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',
      { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: form }
    );
  }
}

export async function loadData(token) {
  const folderId = await getOrCreateFolder(token);
  const entriesId = await getFileId(token, folderId, ENTRIES_FILE);
  const expensesId = await getFileId(token, folderId, EXPENSES_FILE);
  const entries = entriesId ? (await readFile(token, entriesId)) || [] : [];
  const expenses = expensesId ? (await readFile(token, expensesId)) || [] : [];
  return { entries, expenses, folderId };
}

export async function saveEntries(token, folderId, entries) {
  const existingId = await getFileId(token, folderId, ENTRIES_FILE);
  await writeFile(token, folderId, ENTRIES_FILE, entries, existingId);
}

export async function saveExpenses(token, folderId, expenses) {
  const existingId = await getFileId(token, folderId, EXPENSES_FILE);
  await writeFile(token, folderId, EXPENSES_FILE, expenses, existingId);
}
